<?php

/**--------------------------------------------------------------
 * Register Custom Post Type: Team
 *--------------------------------------------------------------*/

function portolite_core_register_team_cpt()
{

    $labels = array(
        'name'               => __('Team Members', 'portolite-core'),
        'singular_name'      => __('Team Member', 'portolite-core'),
        'menu_name'          => __('Team', 'portolite-core'),
        'add_new'            => __('Add New', 'portolite-core'),
        'add_new_item'       => __('Add New Team Member', 'portolite-core'),
        'edit_item'          => __('Edit Team Member', 'portolite-core'),
        'all_items'          => __('All Team Members', 'portolite-core'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'menu_icon'          => 'dashicons-groups',
        'supports'           => array('title', 'editor', 'thumbnail'),
        'rewrite'            => array('slug' => 'team'),
        'show_in_rest'       => true,
    );

    register_post_type('team', $args);
}
add_action('init', 'portolite_core_register_team_cpt');

