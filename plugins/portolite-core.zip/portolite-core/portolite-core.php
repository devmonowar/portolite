<?php

/**
 * Plugin Name: Portolite Core
 * Plugin URI:  https://your-website.com/
 * Description: Core functionality plugin for the Portolite theme. Includes custom post types, ACF sections, shortcodes, and helper functions.
 * Version:     1.0.0
 * Author:      Monowar Hossain
 * Author URI:  https://your-website.com/
 * Text Domain: portolite-core
 * Domain Path: /languages
 */

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Load plugin textdomain
 */
function portolite_core_load_textdomain()
{
    load_plugin_textdomain(
        'portolite-core',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
}
add_action('init', 'portolite_core_load_textdomain');

/**
 * Define constants
 */
if (! defined('PORTOLITE_CORE_PATH')) {
    define('PORTOLITE_CORE_PATH', plugin_dir_path(__FILE__));
}

if (! defined('PORTOLITE_CORE_URL')) {
    define('PORTOLITE_CORE_URL', plugin_dir_url(__FILE__));
}

/**
 * Include required files
 */
function portolite_core_includes()
{
    // Post Types
    require_once PORTOLITE_CORE_PATH . 'inc/post-types/team.php';

    // Helpers
    if (file_exists(PORTOLITE_CORE_PATH . 'inc/helpers.php')) {
        require_once PORTOLITE_CORE_PATH . 'inc/helpers.php';
    }

    // Future: Shortcodes
    if (file_exists(PORTOLITE_CORE_PATH . 'inc/shortcodes/example-shortcode.php')) {
        require_once PORTOLITE_CORE_PATH . 'inc/shortcodes/example-shortcode.php';
    }
}
add_action('plugins_loaded', 'portolite_core_includes');
